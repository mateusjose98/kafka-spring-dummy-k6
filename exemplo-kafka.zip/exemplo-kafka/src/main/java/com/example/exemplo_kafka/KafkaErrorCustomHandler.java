package com.example.exemplo_kafka;

import org.springframework.kafka.listener.KafkaListenerErrorHandler;
import org.springframework.kafka.listener.ListenerExecutionFailedException;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component
public class KafkaErrorCustomHandler implements KafkaListenerErrorHandler {


    @Override
    public Object handleError(
            Message<?> message,
            ListenerExecutionFailedException exception) {
        System.out.println("Error on message: " + message.getPayload());
        return null;
    }
}
