package com.example.exemplo_kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@RequiredArgsConstructor
public class ExemploKafkaApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(ExemploKafkaApplication.class, args);
	}

	private final Producer1 producer1;

	@Override
	public void run(String... args) throws Exception {
		for (int i = 0; i < 10; i++) {
			producer1.sendMessage("pagamento", "msg__" + i);
			producer1.sendMessage("pix", "msg__" + i);
		}
	}
}
