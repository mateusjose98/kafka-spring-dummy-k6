package com.example.exemplo_kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class Producer1 {

    private final KafkaTemplate<String, String> kafkaTemplate;


    public void sendMessage(String topico, String message) {
        if (true){
            kafkaTemplate.send(topico, message).whenComplete(
                    (result, ex) -> {
                        if (ex != null) {
                            ex.printStackTrace();
                        } else {

                        }
                    }
            );
        }

    }

}
