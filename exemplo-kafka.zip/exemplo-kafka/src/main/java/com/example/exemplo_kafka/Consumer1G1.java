package com.example.exemplo_kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer1G1 {


    @KafkaListener(topics = "pagamento", groupId = "group1", errorHandler = "kafkaErrorCustomHandler")
    public void consume(String message) {
        if(message.contains("msg__9")) {
            throw new RuntimeException("Erro ao processar mensagem");
        }
        System.out.println(" G1/C1 :: [PAGAMENTO] message: " + message);
    }

    @KafkaListener(topics = "pagamento", groupId = "group2")
    public void consume2(String message) {
        System.out.println(" G2/C1 :: [PAGAMENTO] message: " + message);
    }

    @KafkaListener(topics = "pagamento", groupId = "group1")
    public void consume3(String message) {
        System.out.println(" G1/C2 :: [PAGAMENTO] message: " + message);
    }

    @KafkaListener(topics = "pix", groupId = "group2")
    public void consume4(String message) {
        System.out.println(" G2/C1 :: [PIX] message: " + message);
    }

}
